NK-IOSOE Cluster Package Layout
================================

Extract with:
    tar -xzf nk_iosoe_cluster_YYYYMMDD.tar.gz

Expected directory tree after extraction:

    nk_iosoe_cluster/
    ├── julia_code/          ← Julia source files
    │   ├── run_smm_estimation.jl
    │   ├── smm_estimation.jl
    │   ├── smm_model_moments.jl
    │   ├── utils.jl
    │   ├── steady_ntwsoe.jl
    │   ├── steady_ntwsoe_system.jl
    │   └── mod/
    │       ├── nk_iosoe_context.jls        ← compiled model (15 MB)
    │       ├── dynare_endo_names.csv
    │       ├── params_jl.mod
    │       ├── NK_SOE_lev_gap2.mod
    │       └── NK_SOE_lev_gap2/model/julia/  ← compiled Jacobians
    ├── Data/
    │   ├── sectoral_moments.csv
    │   └── aggregate_moments.csv
    └── cluster/
        ├── run_smm_hpc.sh       ← SLURM submission script
        ├── setup_cluster.jl     ← one-time package install
        └── Project.toml         ← Julia package spec

STEPS ON CLUSTER:
  1. cd nk_iosoe_cluster
  2. julia --project=cluster cluster/setup_cluster.jl    # first time only
  3. sbatch cluster/run_smm_hpc.sh

OUTPUT FILES (written to Data/):
  smm_results.csv      — full moment-fit table
  smm_estimates.csv    — estimated parameters
  smm_checkpoint.csv   — warm-start checkpoint
  smm_results_JOBID.csv, smm_estimates_JOBID.csv  — job-stamped copies
